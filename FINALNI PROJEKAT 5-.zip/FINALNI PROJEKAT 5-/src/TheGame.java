import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;


public class TheGame {

	
	
    private final Player player;
    private final List<Enemy> enemies;
    private final List<String> eventLog;

    public TheGame(Player player) {
        if (player == null) {
            throw new IllegalArgumentException("Player ne smije biti null");
        }
        this.player = player;
        this.enemies = new ArrayList<>();
        this.eventLog = new ArrayList<>();
    }

    public Player getPlayer() { return player; }
    public List<Enemy> getEnemies() { return enemies; }
    public List<String> getEventLog() { return eventLog; }

    public void addEnemy(Enemy e) {
        if (e == null) {
            throw new IllegalArgumentException("Enemy ne smije biti null");
        }
        enemies.add(e);
        eventLog.add("ADD: " + e.getDisplayName() + " @ (" + e.getX() + "," + e.getY() + ")");
    }

    public boolean checkCollision(Player p, Enemy e) {
        return p.intersects(e);
    }

    public void decreaseHealth(Player p, Enemy e) {
        int before = p.getHealth();
        int dmg = e.getEffectiveDamage();
        int after = Math.max(0, before - dmg);
        p.setHealth(after);

        eventLog.add("HIT: Player by " + e.getDisplayName()
                + " for " + dmg + " -> HP " + before + " -> " + after);
    }

    public List<Enemy> collidingWithPlayer() {
        List<Enemy> col = new ArrayList<>();
        for (Enemy e : enemies) {
            if (checkCollision(player, e)) col.add(e);
        }
        return col;
    }

    public void resolveCollisions() {
        for (Enemy e : enemies) {
            if (checkCollision(player, e)) decreaseHealth(player, e);
        }
    }

    
    
    
    
    public static List<Enemy> loadEnemiesFromCSV(String filePath) {

        List<Enemy> list = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {

            String line = br.readLine(); // header
            if (line == null) {
                throw new IllegalArgumentException("CSV fajl je prazan");
            }

            while ((line = br.readLine()) != null) {
                if (line.trim().isEmpty()) continue;

                String[] p = line.split(",");

                if (p.length < 10) {
                    throw new IllegalArgumentException("Neispravna CSV linija: " + line);
                }

                String type = p[0].trim();
                String clazz = p[1].trim().toLowerCase();
                int damage = Integer.parseInt(p[2].trim());
                int health = Integer.parseInt(p[3].trim());
                int x = Integer.parseInt(p[4].trim());
                int y = Integer.parseInt(p[5].trim());
                String shape = p[6].trim().toLowerCase();

                Collidable collider;

                if (shape.equals("rectangle")) {
                    int w = Integer.parseInt(p[7].trim());
                    int h = Integer.parseInt(p[8].trim());
                    collider = new RectangleCollider(x, y, w, h);

                } else if (shape.equals("circle")) {
                    int r = Integer.parseInt(p[9].trim());
                    collider = new CircleCollider(x, y, r);

                } else {
                    throw new IllegalArgumentException("Nepoznat shape: " + shape);
                }

                Enemy enemy;
                if (clazz.equals("boss")) {
                    enemy = new BossEnemy(x, y, collider, type, damage, health);

                } else if (clazz.equals("melee")) {
                    enemy = new MeleeEnemy(x, y, collider, type, damage, health);

                } else {
                    enemy = new Enemy(x, y, collider, type, damage, health);
                }

                list.add(enemy);
            }

        } catch (IOException e) {
            throw new IllegalArgumentException("Greska pri citanju CSV fajla: " + e.getMessage());
        }

        return list;
    }
}
